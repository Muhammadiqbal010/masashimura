<template>
  <div class="login-root">

    <!-- ── PANEL KIRI (hero) ──────────────────────────────────────── -->
    <div class="hero-panel">
      <div
        class="hero-bg"
        :style="{ backgroundImage: `url(${heroImage})` }"
      />
      <div class="hero-overlay-bottom" />
      <div class="hero-overlay-side" />

      <div class="hero-content">
        <!-- Top label -->
        <div class="hero-top">
          <span class="hero-badge">
            <span class="hero-badge-dot"></span>
            Premium Quality
          </span>
        </div>

        <!-- Bottom branding -->
        <div class="hero-bottom">
          <img
            src="@/assets/masashimura-logo.png"
            alt="Masashimura"
            class="hero-logo"
            onerror="this.style.display='none'"
          />
          <h2 class="hero-tagline">Admin ERP System</h2>
          <p class="hero-desc">
            Infrastruktur manajemen internal, rekap finansial, kontrol stok, dan kasir POS terintegrasi Masashimura Bekasi.
          </p>
          <div class="hero-stats">
            <div class="hero-stat">
              <span class="stat-num">POS</span>
              <span class="stat-lbl">Kasir</span>
            </div>
            <div class="hero-stat-div"></div>
            <div class="hero-stat">
              <span class="stat-num">ERP</span>
              <span class="stat-lbl">Finansial</span>
            </div>
            <div class="hero-stat-div"></div>
            <div class="hero-stat">
              <span class="stat-num">CRM</span>
              <span class="stat-lbl">Loyalitas</span>
            </div>
          </div>
        </div>

        <p class="hero-copy">© 2026 Masashimura Corporation. All Rights Reserved.</p>
      </div>
    </div>

    <!-- ── PANEL KANAN (form) ─────────────────────────────────────── -->
    <div class="form-panel">
      <div class="form-inner">

        <!-- Header -->
        <div class="form-header">
          <p class="form-eyebrow">Masashimura · Admin ERP</p>
          <h1 class="form-title">Masuk ke Sistem</h1>
          <p class="form-subtitle">Masukkan kredensial otorisasi untuk mengakses ruang kendali.</p>
        </div>

        <!-- Form -->
        <form @submit.prevent="handleSubmit" class="login-form">

          <div class="field">
            <label class="field-label">Username / Email Karyawan</label>
            <div class="input-wrap">
              <svg class="input-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
              <input
                v-model="formData.username"
                type="text"
                required
                autocomplete="username"
                :disabled="loading"
                placeholder="username anda..."
                class="text-input"
              />
            </div>
          </div>

          <div class="field">
            <label class="field-label">Kata Sandi</label>
            <div class="input-wrap">
              <svg class="input-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
              <input
                v-model="formData.password"
                :type="showPassword ? 'text' : 'password'"
                required
                autocomplete="current-password"
                :disabled="loading"
                placeholder="••••••••"
                class="text-input pr-input"
              />
              <button type="button" class="eye-btn" @click="showPassword = !showPassword">
                <component :is="showPassword ? EyeOff : Eye" :size="15" />
              </button>
            </div>
          </div>

          <button type="submit" :disabled="loading" class="submit-btn">
            <span v-if="loading" class="btn-spinner"></span>
            <svg v-else width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M15 3h4a2 2 0 012 2v14a2 2 0 01-2 2h-4M10 17l5-5-5-5M15 12H3"/></svg>
            {{ loading ? 'Memverifikasi...' : 'Masuk ke Sistem' }}
          </button>

        </form>

        <!-- Forgot password -->
        <div class="forgot-wrap">
          <button @click="openForgotModal" class="forgot-btn">
            Lupa password akun?
          </button>
        </div>

        <!-- Footer -->
        <p class="form-footer">Akses terbatas untuk staff & operator Masashimura</p>

      </div>
    </div>

    <!-- ── MODAL RESET PASSWORD ───────────────────────────────────── -->
    <!-- ── MODAL RESET PASSWORD ───────────────────────────────────── -->
<div v-if="isForgotModalOpen" class="modal-overlay" @click.self="isForgotModalOpen = false">
  <div class="modal-box">

    <div class="modal-header">
      <div>
        <p class="modal-eyebrow">Keamanan Akun</p>
        <h3 class="modal-title">Reset Password</h3>
      </div>
      <button class="modal-close" @click="isForgotModalOpen = false">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M18 6L6 18M6 6l12 12"/></svg>
      </button>
    </div>

    <p class="modal-desc">Masukkan username kamu dan PIN keamanan yang dikasih owner saat akun dibuat.</p>

    <form @submit.prevent="handleSelfResetPassword" class="modal-form">

      <div class="field">
        <label class="field-label">Username</label>
        <div class="input-wrap">
          <svg class="input-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
          <input v-model="resetForm.username" type="text" required placeholder="username kamu..." class="text-input" />
        </div>
      </div>

      <div class="field">
        <label class="field-label">PIN Keamanan</label>
        <div class="input-wrap">
          <svg class="input-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
          <input
            v-model="resetForm.securityPin"
            type="text" inputmode="numeric" maxlength="6" required
            placeholder="6 digit PIN..."
            class="text-input"
            @input="resetForm.securityPin = resetForm.securityPin.replace(/\D/g, '').slice(0, 6)"
          />
        </div>
      </div>

      <div class="field">
        <label class="field-label">Password Baru</label>
        <div class="input-wrap">
          <svg class="input-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
          <input
            v-model="resetForm.newPassword"
            :type="showResetPassword ? 'text' : 'password'"
            required placeholder="Minimal 6 karakter..." class="text-input pr-input"
          />
          <button type="button" class="eye-btn" @click="showResetPassword = !showResetPassword">
            <component :is="showResetPassword ? EyeOff : Eye" :size="15" />
          </button>
        </div>
      </div>

      <div class="modal-actions">
        <button type="submit" :disabled="isResetting" class="submit-btn">
          <span v-if="isResetting" class="btn-spinner"></span>
          {{ isResetting ? 'Memproses...' : 'Ganti Password' }}
        </button>
        <button type="button" @click="isForgotModalOpen = false" class="cancel-btn">Batalkan</button>
      </div>

    </form>
  </div>
</div>

  </div>
</template>

<script setup>
import { ref } from "vue";
import { useRouter } from "vue-router";
import { useAuthStore } from "@/stores/auth";
import { toast } from "vue-sonner";
import { Eye, EyeOff } from "lucide-vue-next";
import apiClient from "@/api/client";

const router = useRouter();
const auth   = useAuthStore();

const showPassword      = ref(false);
const showResetPassword = ref(false);
const loading           = ref(false);
const isResetting       = ref(false);
const isForgotModalOpen = ref(false);

const formData  = ref({ username: "", password: "" });
const resetForm = ref({ username: "", securityPin: "", newPassword: "" });

const heroImage = "https://images.unsplash.com/photo-1569718212165-3a8278d5f624?q=80&w=2080";

const openForgotModal = () => {
  resetForm.value = { username: "", securityPin: "", newPassword: "" };
  showResetPassword.value = false;
  isForgotModalOpen.value = true;
};

const handleSubmit = async () => {
  loading.value = true;
  try {
    await auth.login({ username: formData.value.username.trim(), password: formData.value.password });
    toast.success(`Akses diberikan. Selamat datang, ${auth.user?.name || "Admin"}!`);
    if (auth.isOwner || auth.isAdmin) router.push("/admin");
    else if (auth.isKasir) router.push("/admin/orders");
    else router.push("/");
  } catch (error) {
    if (error.response?.status === 429) {
      toast.error("Terlalu banyak percobaan login. Coba lagi dalam beberapa menit.");
    } else {
      toast.error(error.response?.data?.non_field_errors?.[0] || "Username atau password salah.");
    }
  } finally {
    loading.value = false;
  }
};

const handleSelfResetPassword = async () => {
  if (!/^\d{6}$/.test(resetForm.value.securityPin)) return toast.error("PIN harus 6 digit angka!");
  if (resetForm.value.newPassword.length < 6) return toast.error("Password minimal 6 karakter!");

  isResetting.value = true;
  try {
    await apiClient.post("/auth/reset-password-pin/", {
      username: resetForm.value.username.trim(),
      security_pin: resetForm.value.securityPin,
      new_password: resetForm.value.newPassword,
    });
    toast.success("Password berhasil diubah. Silakan login.");
    isForgotModalOpen.value = false;
  } catch (error) {
    if (error.response?.status === 429) {
      toast.error("Terlalu banyak percobaan. Coba lagi dalam beberapa menit.");
    } else {
      toast.error(error.response?.data?.detail || "Username atau PIN salah.");
    }
  } finally {
    isResetting.value = false;
  }
};
</script>

<style scoped>
/* ── Root ──────────────────────────────────────────────────────────── */
.login-root {
  min-height: 100vh;
  display: flex;
  background: #111113;
  font-family: 'Inter', sans-serif;
  color: #fff;
}

/* ── Hero Panel ────────────────────────────────────────────────────── */
.hero-panel {
  display: none;
  position: relative;
  overflow: hidden;
  border-right: 1px solid rgba(255,255,255,0.05);
}
@media (min-width: 1024px) {
  .hero-panel { display: flex; width: 50%; }
}

.hero-bg {
  position: absolute; inset: 0;
  background-size: cover; background-position: center;
  transition: transform 1.2s ease;
}
.hero-panel:hover .hero-bg { transform: scale(1.04); }

.hero-overlay-bottom {
  position: absolute; inset: 0;
  background: linear-gradient(to top, #000 0%, rgba(0,0,0,0.5) 45%, rgba(0,0,0,0.15) 100%);
}
.hero-overlay-side {
  position: absolute; inset: 0;
  background: linear-gradient(to right, rgba(120,0,0,0.3) 0%, transparent 60%);
}

.hero-content {
  position: relative; z-index: 10;
  display: flex; flex-direction: column;
  justify-content: space-between;
  padding: 3rem 3.5rem;
  width: 100%; height: 100%;
}

.hero-top { }
.hero-badge {
  display: inline-flex; align-items: center; gap: 0.5rem;
  padding: 0.35rem 0.85rem;
  background: rgba(217,43,34,0.12);
  border: 1px solid rgba(217,43,34,0.25);
  border-radius: 100px;
  font-family: 'Manrope', system-ui, sans-serif;
  font-size: 0.72rem; letter-spacing: -0.01em;
  color: #ff9a9a;
}
.hero-badge-dot {
  width: 5px; height: 5px; border-radius: 50%; background: #f0524a;
  animation: pulse 2s infinite;
}
@keyframes pulse { 0%,100% { opacity:1; } 50% { opacity:0.4; } }

.hero-bottom { display: flex; flex-direction: column; gap: 1rem; }
.hero-logo {
  width: 220px; object-fit: contain;
  filter: drop-shadow(0 10px 30px rgba(0,0,0,0.8));
  user-select: none;
}
.hero-tagline {
  font-family: 'Manrope', system-ui, sans-serif;
  font-size: 1.1rem; font-weight: 600; letter-spacing: -0.01em;
  color: rgba(255,255,255,0.7); margin: 0;
}
.hero-desc {
  font-size: 0.78rem; color: rgba(255,255,255,0.6);
  line-height: 1.7; margin: 0; max-width: 340px;
}
.hero-stats {
  display: flex; align-items: center; gap: 1.5rem;
  margin-top: 0.5rem;
}
.hero-stat { display: flex; flex-direction: column; gap: 0.15rem; }
.stat-num {
  font-family: 'Manrope', system-ui, sans-serif; font-size: 1rem;
  font-weight: 600; letter-spacing: -0.01em; color: #fff;
}
.stat-lbl { font-size: 0.72rem; color: rgba(255,255,255,0.6); letter-spacing: 0.1em; text-transform: uppercase; }
.hero-stat-div { width: 1px; height: 28px; background: rgba(255,255,255,0.1); }

.hero-copy { font-size: 0.72rem; color: rgba(255,255,255,0.5); font-family: monospace; }

/* ── Form Panel ────────────────────────────────────────────────────── */
.form-panel {
  flex: 1;
  display: flex; align-items: center; justify-content: center;
  padding: 3rem 1.5rem;
  background: linear-gradient(160deg, #17171A 0%, #111113 100%);
}
.form-inner {
  width: 100%; max-width: 380px;
  display: flex; flex-direction: column; gap: 1.75rem;
}

.form-header { display: flex; flex-direction: column; gap: 0.5rem; }
.form-eyebrow {
  font-family: 'Manrope', system-ui, sans-serif; font-size: 0.72rem;
  letter-spacing: -0.01em; color: #d92b22;
}
.form-title {
  font-family: 'Manrope', system-ui, sans-serif; font-size: 2rem;
  font-weight: 600; letter-spacing: -0.01em;
  margin: 0; color: #fff;
}
.form-subtitle { font-size: 0.75rem; color: rgba(255,255,255,0.6); line-height: 1.6; }

/* ── Form fields ───────────────────────────────────────────────────── */
.login-form { display: flex; flex-direction: column; gap: 1rem; }
.modal-form { display: flex; flex-direction: column; gap: 1rem; }

.field { display: flex; flex-direction: column; gap: 0.4rem; }
.field-label {
  font-family: 'Manrope', system-ui, sans-serif; font-size: 0.72rem;
  letter-spacing: -0.01em;
  color: rgba(255,255,255,0.6);
}

.input-wrap { position: relative; display: flex; align-items: center; }
.input-icon {
  position: absolute; left: 0.9rem;
  color: rgba(255,255,255,0.5); pointer-events: none; flex-shrink: 0;
}
.text-input {
  width: 100%; background: rgba(255,255,255,0.04);
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 12px; padding: 0.8rem 1rem 0.8rem 2.5rem;
  color: #fff; font-size: 0.85rem;
  font-family: 'Inter', monospace; outline: none;
  transition: border-color 0.15s, background 0.15s;
  -webkit-appearance: none;
}
.text-input::placeholder { color: rgba(255,255,255,0.5); }
.text-input:focus { border-color: rgba(217,43,34,0.5); background: rgba(255,255,255,0.06); }
.text-input:disabled { opacity: 0.45; cursor: not-allowed; }
.pr-input { padding-right: 2.75rem; }

.eye-btn {
  position: absolute; right: 0.85rem;
  background: none; border: none; padding: 0;
  color: rgba(255,255,255,0.5); cursor: pointer;
  transition: color 0.15s; display: flex; align-items: center;
}
.eye-btn:hover { color: rgba(255,255,255,0.7); }

/* ── Submit btn ────────────────────────────────────────────────────── */
.submit-btn {
  width: 100%; display: flex; align-items: center; justify-content: center; gap: 0.5rem;
  padding: 0.9rem; border-radius: 12px; border: none;
  background: #d92b22; color: #fff;
  font-family: 'Manrope', system-ui, sans-serif; font-size: 0.78rem;
  letter-spacing: -0.01em;
  cursor: pointer; transition: background 0.15s, opacity 0.15s;
  box-shadow: 0 4px 20px rgba(217,43,34,0.2);
  margin-top: 0.25rem;
}
.submit-btn:hover:not(:disabled) { background: #b8201a; }
.submit-btn:disabled { opacity: 0.4; cursor: not-allowed; }

.btn-spinner {
  width: 15px; height: 15px;
  border: 2px solid rgba(255,255,255,0.3);
  border-top-color: #fff; border-radius: 50%;
  animation: spin 0.75s linear infinite; flex-shrink: 0;
}
@keyframes spin { to { transform: rotate(360deg); } }

/* ── Forgot ────────────────────────────────────────────────────────── */
.forgot-wrap { text-align: center; }
.forgot-btn {
  background: none; border: none;
  font-size: 0.72rem; color: rgba(255,255,255,0.5);
  cursor: pointer; transition: color 0.15s;
  text-decoration: underline; text-underline-offset: 3px;
  text-decoration-color: rgba(255,255,255,0.1);
}
.forgot-btn:hover { color: #ff9a9a; text-decoration-color: rgba(217,43,34,0.4); }

.form-footer {
  text-align: center; font-size: 0.72rem;
  color: rgba(255,255,255,0.5); margin: 0;
  font-family: monospace; letter-spacing: 0.05em;
}

/* ── Modal ─────────────────────────────────────────────────────────── */
.modal-overlay {
  position: fixed; inset: 0; z-index: 50;
  background: rgba(0,0,0,0.8); backdrop-filter: blur(6px);
  display: flex; align-items: center; justify-content: center;
  padding: 1rem;
  animation: fadeIn 0.18s ease;
}
@keyframes fadeIn { from { opacity:0; } to { opacity:1; } }

.modal-box {
  background: #0f0f0f;
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 20px;
  width: 100%; max-width: 420px;
  padding: 1.75rem;
  display: flex; flex-direction: column; gap: 1.25rem;
  box-shadow: 0 20px 60px rgba(0,0,0,0.6);
  animation: slideUp 0.2s ease;
}
@keyframes slideUp { from { transform: translateY(12px); opacity:0; } to { transform: translateY(0); opacity:1; } }

.modal-header {
  display: flex; align-items: flex-start; justify-content: space-between;
}
.modal-eyebrow {
  font-family: 'Manrope', system-ui, sans-serif; font-size: 0.72rem;
  letter-spacing: -0.01em;
  color: #d92b22; margin: 0 0 0.25rem;
}
.modal-title {
  font-family: 'Manrope', system-ui, sans-serif; font-size: 1.15rem;
  font-weight: 600; letter-spacing: -0.01em; margin: 0;
}
.modal-close {
  width: 30px; height: 30px; border-radius: 8px;
  background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.08);
  color: rgba(255,255,255,0.6); cursor: pointer;
  display: flex; align-items: center; justify-content: center;
  transition: all 0.15s; flex-shrink: 0;
}
.modal-close:hover { background: rgba(255,255,255,0.1); color: #fff; }

.modal-desc { font-size: 0.74rem; color: rgba(255,255,255,0.6); line-height: 1.65; margin: 0; }

.modal-actions { display: grid; grid-template-columns: 1fr 1fr; gap: 0.6rem; margin-top: 0.25rem; }
.cancel-btn {
  padding: 0.85rem; border-radius: 12px;
  background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.08);
  color: rgba(255,255,255,0.6);
  font-family: 'Manrope', system-ui, sans-serif; font-size: 0.72rem;
  letter-spacing: -0.01em;
  cursor: pointer; transition: all 0.15s;
}
.cancel-btn:hover { background: rgba(255,255,255,0.08); color: rgba(255,255,255,0.8); }

/* ── Mobile: show minimal branding strip ──────────────────────────── */
@media (max-width: 1023px) {
  .form-panel {
    background:
      linear-gradient(160deg, #17171A 0%, #111113 100%);
    min-height: 100vh;
  }
  .form-inner { max-width: 420px; }
}
</style>