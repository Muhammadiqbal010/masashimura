// src/main.js
import { createApp } from "vue";
import { createPinia } from "pinia";
import App from "./App.vue";
import router from "./router";
import { useAuthStore } from "./stores/auth";
import "./index.css";
import "@/assets/admin-theme.css";
import "@/assets/admin-ui.css";
import { initViewportVars } from "@/utils/touch";

const app = createApp(App);
const pinia = createPinia();

app.use(pinia);
app.use(router);

// Inisialisasi Auth Store setelah Pinia aktif
const auth = useAuthStore();
auth.checkAuth(); // Ini penting agar user langsung ter-load

initViewportVars();
app.mount("#app");