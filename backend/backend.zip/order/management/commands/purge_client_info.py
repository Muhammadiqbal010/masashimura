"""
Hapus jejak IP/lokasi dari order lama (IP termasuk data pribadi; simpan seperlunya saja).

  python manage.py purge_client_info --dry-run     # lihat berapa yang akan dihapus
  python manage.py purge_client_info --days 90     # hapus jejak order yang lebih tua dari 90 hari

Hanya menghapus kolom jejak (client_ip, client_info); order, total, dan laporan tidak tersentuh.
"""
from datetime import timedelta

from django.core.management.base import BaseCommand
from django.db.models import Q
from django.utils import timezone

from order.models import Order


class Command(BaseCommand):
    help = "Hapus jejak IP/lokasi pemesan dari order yang lebih tua dari N hari"

    def add_arguments(self, parser):
        parser.add_argument("--days", type=int, default=90, help="Umur minimal order (hari), bawaan 90")
        parser.add_argument("--dry-run", action="store_true", help="Hanya hitung, jangan hapus")

    def handle(self, *args, **opts):
        days = max(int(opts["days"]), 1)
        cutoff = timezone.now() - timedelta(days=days)
        qs = Order.objects.filter(created_at__lt=cutoff).filter(Q(client_ip__isnull=False) | ~Q(client_info={}))
        count = qs.count()
        if opts["dry_run"]:
            self.stdout.write(f"{count} order lebih tua dari {days} hari masih menyimpan jejak (dry-run, tidak ada yang dihapus).")
            return
        qs.update(client_ip=None, client_info={})
        self.stdout.write(self.style.SUCCESS(f"Jejak dihapus dari {count} order (lebih tua dari {days} hari)."))
