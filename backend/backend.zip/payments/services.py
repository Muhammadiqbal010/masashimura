import logging

import midtransclient
from django.conf import settings

logger = logging.getLogger(__name__)

_keys = dict(
    is_production=settings.MIDTRANS_IS_PRODUCTION,
    server_key=settings.MIDTRANS_SERVER_KEY,
    client_key=settings.MIDTRANS_CLIENT_KEY,
)

snap = midtransclient.Snap(**_keys)
core = midtransclient.CoreApi(**_keys)


def cancel_midtrans_transaction(order_number):
    """Batalkan transaksi pending di Midtrans (dipakai saat admin cancel order)."""
    try:
        core.transactions.cancel(order_number)
    except Exception:
        logger.warning("Gagal cancel transaksi Midtrans %s", order_number, exc_info=True)


def fetch_midtrans_status(order_number):
    """Ambil status transaksi LANGSUNG dari Midtrans (bukan dari body webhook)."""
    return core.transactions.status(order_number)